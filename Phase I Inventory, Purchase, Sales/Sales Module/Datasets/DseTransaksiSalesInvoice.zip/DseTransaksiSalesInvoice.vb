﻿Partial Class DseTransaksiSalesInvoice

    Partial Class tbltrans_salesinvoice_viewDataTable

        Private Sub tbltrans_salesinvoice_viewDataTable_tbltrans_salesinvoice_viewRowChanging(ByVal sender As System.Object, ByVal e As tbltrans_salesinvoice_viewRowChangeEvent) Handles Me.tbltrans_salesinvoice_viewRowChanging

        End Sub

    End Class

End Class
